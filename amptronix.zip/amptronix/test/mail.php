
<?php

return [
    "host" => "mail.amptronix.co.in",
    "username" => "sales@amptronix.co.in",
    "password" => getenv("AMPTRONIX_MAIL_PASSWORD") ?: "",
    "port" => 465,
    "encryption" => "ssl",
    "from_email" => "sales@amptronix.co.in",
    "from_name" => "Amptronix Website",
    "admin_email" => "sales@amptronix.co.in"
];
